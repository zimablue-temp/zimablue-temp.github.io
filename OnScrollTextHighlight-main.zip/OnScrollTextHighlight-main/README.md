# On-Scroll Text Highlight Effects

Some scroll-based text highlight effects.

![Text Highlight](https://tympanus.net/codrops/wp-content/uploads/2024/04/TextHighlight.jpg?x32096)

[Article on Codrops](https://tympanus.net/codrops/?p=76961)

[Demo](https://tympanus.net/Development/OnScrollTextHighlight/)

## Installation

Run this demo on a [local server](https://developer.mozilla.org/en-US/docs/Learn/Common_questions/Tools_and_setup/set_up_a_local_testing_server).

## Misc

Follow Codrops: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/codrops), [GitHub](https://github.com/codrops), [Instagram](https://www.instagram.com/codropsss/)

## License
[MIT](LICENSE)

Made with :blue_heart:  by [Codrops](http://www.codrops.com)





